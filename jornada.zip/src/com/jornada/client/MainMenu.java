package com.jornada.client;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Hyperlink;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.VerticalPanel;

public class MainMenu extends Composite {
	
	MainView mainView;
	
	public MainMenu(MainView mainView){
		
		this.mainView = mainView; 
		
		
		
	    HorizontalPanel hPanel = new HorizontalPanel();
	    hPanel.setStyleName("titulo_tabela");
	    hPanel.setSize("210px", "20px");
	    
	    Image image = new Image("images/home-icon.png");
	    hPanel.add(image);
	    
	    Hyperlink lblNewLabel_2 = new Hyperlink("home","Principal");
	    lblNewLabel_2.setStyleName("a");
	    lblNewLabel_2.addClickHandler(new addClickHandler());
	    hPanel.add(lblNewLabel_2);
	    
	    Label lblNewLabel_3 = new Label(" >> ");
	    hPanel.add(lblNewLabel_3);
	    
	    Image image_1 = new Image("images/blockdevice_16.png");
	    hPanel.add(image_1);
	    
	    Label lblNewLabel_4 = new Label("Administra\u00E7\u00E3o");
	    hPanel.add(lblNewLabel_4);
	    

	    
	    VerticalPanel vPanel = new VerticalPanel();
	    VerticalPanel vPanelBlank = new VerticalPanel();
	    vPanelBlank.setSize("10px", "10px");
	    vPanel.add(vPanelBlank);
	    vPanel.add(hPanel);
	    
	    
		
		initWidget(vPanel);
		
	}
	
	private class addClickHandler implements ClickHandler{

		@Override
		public void onClick(ClickEvent event) {
			// TODO Auto-generated method stub
			mainView.openMainView();
			
		}
		
	}

}
