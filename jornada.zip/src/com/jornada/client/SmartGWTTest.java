package com.jornada.client;

import com.google.gwt.user.client.ui.Composite;
import com.smartgwt.client.widgets.tree.TreeGrid;

public class SmartGWTTest extends Composite {
	
	public SmartGWTTest(){
		
		TreeGrid treeGrid = new TreeGrid();
		initWidget(treeGrid);
		
	}

}
