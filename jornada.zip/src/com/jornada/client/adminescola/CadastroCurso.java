package com.jornada.client.adminescola;

import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.PushButton;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HasVerticalAlignment;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.Grid;
import com.google.gwt.user.client.ui.RichTextArea;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.SimplePanel;
import com.jornada.client.classes.FadeAnimation;
import com.jornada.client.classes.WorldXmlDS;
import com.smartgwt.client.types.AnimationEffect;
import com.smartgwt.client.widgets.Button;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.IButton;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.DateItem;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.layout.VLayout;

public class CadastroCurso extends Composite {
	
	public ListGrid countryGrid;
	public CadastroCurso() {
		

		VerticalPanel verticalPanelPage = new VerticalPanel();

		VerticalPanel verticalPanelTitle = new VerticalPanel();
		verticalPanelTitle.setSize("10px", "10px");
		
		VerticalPanel verticalPanelFooter = new VerticalPanel();
		verticalPanelFooter.setSize("10px", "10px");
		
		
		VerticalPanel verticalPanelBody = new VerticalPanel();
		verticalPanelBody.setStyleName("fundo_tabela_componente");

		verticalPanelBody.setSize("100%", "100%");
		
		HorizontalPanel horizontalPanel = new HorizontalPanel();
		horizontalPanel.setStyleName("fundo_tabela_cadastro");
		verticalPanelBody.add(horizontalPanel);
		horizontalPanel.setWidth("100%");
		
		Image image = new Image("images/folder_library_16_16.png");
		horizontalPanel.add(image);
		horizontalPanel.setCellWidth(image, "20px");
		image.setSize("", "");
		
		Label lblNewLabel_1 = new Label("Curso");
		lblNewLabel_1.setStyleName("text_tabela_cadastro");
		lblNewLabel_1.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_LEFT);
		horizontalPanel.add(lblNewLabel_1);
		lblNewLabel_1.setWidth("0");
		
		Grid grid = new Grid(6, 3);
		verticalPanelBody.add(grid);
		grid.setSize("493px", "3cm");
		//grid.setSize("100%", "100%");
		
		Label label = new Label("Nome : ");
		grid.setWidget(0, 0, label);
		
		TextBox textBox = new TextBox();
		textBox.setStyleName("design_text_boxes");
		grid.setWidget(0, 2, textBox);
		textBox.setWidth("250px");
		
		Label label_1 = new Label("Descri\u00E7\u00E3o :");
		grid.setWidget(1, 0, label_1);
		
		TextBox textBox_1 = new TextBox();
		textBox_1.setStyleName("design_text_boxes");
		grid.setWidget(1, 2, textBox_1);
		textBox_1.setWidth("250px");
		
		Label label_2 = new Label("Ementa : ");
		grid.setWidget(2, 0, label_2);
		
		RichTextArea richTextArea = new RichTextArea();
		richTextArea.setStyleName("design_text_boxes");
		grid.setWidget(2, 2, richTextArea);
		richTextArea.setWidth("330px");
		
		
		Label label_3 = new Label("Data Inicial : ");
		grid.setWidget(3, 0, label_3);
		
        DateItem dateItem = new DateItem();  
        dateItem.setTitle("");  
        dateItem.setHint("<nobr>Picklist based date input</nobr>");
        DynamicForm dateForm = new DynamicForm(); 
        dateForm.setItems(dateItem);

        grid.setWidget(3, 2, dateForm);
        
		Label label_4 = new Label("Data Final : ");
		grid.setWidget(4, 0, label_4);
		
        DateItem dateItemFinal = new DateItem();  
        dateItemFinal.setTitle("");  
        dateItemFinal.setHint("<nobr>Picklist based date input</nobr>");
        DynamicForm dateFormFinal = new DynamicForm(); 
        dateFormFinal.setItems(dateItemFinal);

        grid.setWidget(4, 2, dateFormFinal);        
		
//		Button button = new Button("New button");
//		button.setText("Salvar Curso");
//	    PushButton pushButton = new PushButton(new Image("image/blockdevice_16.png"));
//	    pushButton.setHTML("<Table cellspacing=2> <tr> <td>" + new Image("image/image002.png") + "</td> <td  align=middle>" + "Salvar Curso" + "</td></tr></Table>");
        final Button cssButton = new Button("Salvar Curso");
        cssButton.setShowRollOver(true);
        cssButton.setShowDisabled(true);
        cssButton.setShowDown(true);
        cssButton.setIcon("../images/image002.png");		
		
		grid.setWidget(5, 2, cssButton);
		//pushButton.setWidth("130px");
		grid.getCellFormatter().setHorizontalAlignment(3, 2, HasHorizontalAlignment.ALIGN_LEFT);
		
		
		verticalPanelPage.add(verticalPanelTitle);
		verticalPanelPage.add(verticalPanelBody);
		verticalPanelPage.add(verticalPanelFooter);
		
		
		
        countryGrid = new ListGrid();  
        countryGrid.setWidth(800);  
        countryGrid.setHeight(150);  
        countryGrid.setShowFilterEditor(false);  
        countryGrid.setFilterOnKeypress(false);  
        countryGrid.setDataSource(WorldXmlDS.getInstance());  
        countryGrid.setAutoFetchData(true);  
  
       // ListGridField countryCodeField = new ListGridField("countryCode", "Code", 50);  
        ListGridField nameField = new ListGridField("courseName", "Nome");  
        ListGridField capitalField = new ListGridField("descricao", "Descricao");  
        ListGridField continentField = new ListGridField("ementa", "Ementa");
        ListGridField dataInicialField = new ListGridField("dataInicial", "Data Inicial");  
        ListGridField dataFinalField = new ListGridField("dataFinal", "Data Final");
        countryGrid.setFields(nameField, capitalField, continentField, dataInicialField, dataFinalField);  
  
        verticalPanelPage.add(countryGrid);
		
		

//		FadeAnimation fadeAnimation = new FadeAnimation(verticalPanelPage.getElement());
//		fadeAnimation.setOpacity(0.0);
//		verticalPanelPage.setVisible(true);
//		fadeAnimation.fade(500, 1.0);	
//        Canvas canvas = new Canvas(); 
//        canvas.addChild(verticalPanelPage);
//        
//        canvas.animateShow(AnimationEffect.WIPE, null, 5000);  
		
		initWidget(verticalPanelPage);		

	}

}
