package com.jornada.client;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.smartgwt.client.types.Alignment;  
import com.smartgwt.client.types.ListGridFieldType;  
import com.smartgwt.client.widgets.Canvas;  
import com.smartgwt.client.widgets.IButton;  
import com.smartgwt.client.widgets.events.ClickEvent;  
import com.smartgwt.client.widgets.events.ClickHandler;  
import com.smartgwt.client.widgets.grid.ListGrid;  
import com.smartgwt.client.widgets.grid.ListGridField;  
//import com.smartgwt.sample.showcase.client.data.CountryData;
import com.smartgwt.client.widgets.layout.HLayout;

public class Jornada implements EntryPoint {	

	MainView mainView = new MainView();
	
	public void onModuleLoad() {	
		
		VerticalPanel vPanel = new VerticalPanel();
		vPanel.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_CENTER);
		vPanel.setSize("100%", "100%");
		vPanel.add(mainView);
		
		//RootPanel.get().add(mainView);
		RootPanel.get().add(vPanel);
	}
}

//public class Jornada implements EntryPoint,ValueChangeHandler<String> {	 
//public class Jornada implements EntryPoint {	
//
//	MainView mainView = new MainView();
//	
//	public void onModuleLoad() {	
//		
//		//RootPanel.get().add(mainView);
//		
//        Canvas canvas = new Canvas();  
//        
//        final ListGrid countryGrid = new ListGrid();  
//        countryGrid.setWidth(500);  
//        countryGrid.setHeight(224);  
//        countryGrid.setShowAllRecords(true);  
//  
//        ListGridField countryCodeField = new ListGridField("countryCode", "Flag", 40);  
//        countryCodeField.setAlign(Alignment.CENTER);  
//        countryCodeField.setType(ListGridFieldType.IMAGE);  
//        countryCodeField.setImageURLPrefix("flags/16/");  
//        countryCodeField.setImageURLSuffix(".png");  
//  
//        ListGridField nameField = new ListGridField("countryName", "Country");  
//        ListGridField capitalField = new ListGridField("capital", "Capital");  
//        ListGridField continentField = new ListGridField("continent", "Continent");  
//        countryGrid.setFields(countryCodeField, nameField, capitalField, continentField);  
//        countryGrid.setCanResizeFields(true);  
//        //countryGrid.setData(CountryData.getRecords());  
//        canvas.addChild(countryGrid);  
//  
//        IButton hideCapital = new IButton("Hide Capitals");  
//        hideCapital.setLeft(0);  
//        hideCapital.setTop(240);  
//        hideCapital.addClickHandler(new ClickHandler() {  
//            public void onClick(ClickEvent event) {  
//                countryGrid.hideField("capital");  
//            }  
//        });  
//        canvas.addChild(hideCapital);  
//  
//        IButton showCapitals = new IButton("Show Capitals");  
//        showCapitals.setLeft(120);  
//        showCapitals.setTop(240);  
//        showCapitals.addClickHandler(new ClickHandler() {  
//            public void onClick(ClickEvent event) {  
//                countryGrid.showField("capital");  
//            }  
//        });  
//        canvas.addChild(showCapitals);  
//  
//        canvas.draw();  
//    }  		
//
//
//}
	
	
//}


